package com.example.inventoryapp;

public class InventoryItem {

    private final long id;
    private String partNumber;
    private String name;
    private String description;
    private int qty;

    public InventoryItem(long id, String partNumber, String name, String description, int qty) {
        this.id = id;
        this.partNumber = partNumber;
        this.name = name;
        this.description = description;
        this.qty = qty;
    }

    public long getId() {
        return id;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getQty() {
        return qty;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }
}