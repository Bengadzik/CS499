package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import android.text.Editable;
import android.text.TextWatcher;

public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.OnItemActionsListener {

    private static final String PREFS = "app_prefs";
    private static final String PREF_PHONE = "sms_phone";

    private DatabaseHelper db;
    private ArrayList<InventoryItem> allItems;
    private ArrayList<InventoryItem> items;
    private InventoryAdapter adapter;

    private EditText etItemName, etItemQty, etSearchInventory;
    private InventoryAlgorithms.SortMode currentSortMode = InventoryAlgorithms.SortMode.NEWEST_FIRST;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        db = new DatabaseHelper(this);

        etItemName = findViewById(R.id.etItemName);
        etItemQty = findViewById(R.id.etItemQty);
        etSearchInventory = findViewById(R.id.etSearchInventory);

        RecyclerView rv = findViewById(R.id.rvInventory);
        rv.setLayoutManager(new GridLayoutManager(this, 2));

        allItems = db.getAllInventoryItems();
        items = new ArrayList<>();
        items.addAll(allItems);

        adapter = new InventoryAdapter(items, this);
        rv.setAdapter(adapter);

        setupSearchFiltering();

        Button btnAdd = findViewById(R.id.btnAddItem);
        btnAdd.setOnClickListener(v -> addItemFromInputs());

        Button btnSortInventory = findViewById(R.id.btnSortInventory);
        btnSortInventory.setOnClickListener(v -> showSortOptionsDialog());

        Button btnLowStock = findViewById(R.id.btnLowStock);
        btnLowStock.setOnClickListener(v -> showLowStockDialog());

        Button btnUsageReport = findViewById(R.id.btnUsageReport);
        btnUsageReport.setOnClickListener(v -> showUsageReportDialog());

        Button btnTopUsedParts = findViewById(R.id.btnTopUsedParts);
        btnTopUsedParts.setOnClickListener(v -> showTopUsedPartsReport());

        Button btnSms = findViewById(R.id.btnSmsSettings);
        btnSms.setOnClickListener(v -> startActivity(new Intent(this, SmsSettingsActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        reloadItems();
    }

    private void reloadItems() {
        allItems.clear();
        allItems.addAll(db.getAllInventoryItems());
        applySearchAndSort();
    }

    private void setupSearchFiltering() {
        etSearchInventory.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                applySearchAndSort();
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });
    }

    private void applySearchAndSort() {
        String searchText = etSearchInventory == null ? "" : etSearchInventory.getText().toString();

        ArrayList<InventoryItem> filteredItems = InventoryAlgorithms.filterItems(allItems, searchText);
        InventoryAlgorithms.sortItems(filteredItems, currentSortMode);

        items.clear();
        items.addAll(filteredItems);
        adapter.notifyDataSetChanged();
    }

    private void addItemFromInputs() {
        String name = etItemName.getText().toString().trim();
        String qtyStr = etItemQty.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(qtyStr)) {
            Toast.makeText(this, "Enter item name and quantity.", Toast.LENGTH_SHORT).show();
            return;
        }

        int qty;
        try {
            qty = Integer.parseInt(qtyStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (qty < 0) {
            Toast.makeText(this, "Quantity cannot be negative.", Toast.LENGTH_SHORT).show();
            return;
        }

        showAddDetailsDialog(name, qty);
    }

    private void showAddDetailsDialog(String name, int qty) {
        EditText etPartNumber = new EditText(this);
        etPartNumber.setHint("Part number");
        etPartNumber.setInputType(android.text.InputType.TYPE_CLASS_TEXT);

        EditText etDescription = new EditText(this);
        etDescription.setHint("Description");
        etDescription.setInputType(android.text.InputType.TYPE_CLASS_TEXT);

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);
        layout.addView(etPartNumber);
        layout.addView(etDescription);

        new AlertDialog.Builder(this)
                .setTitle("Part Details")
                .setView(layout)
                .setPositiveButton("Add", (dialog, which) -> {
                    String partNumber = etPartNumber.getText().toString().trim();
                    String description = etDescription.getText().toString().trim();

                    if (TextUtils.isEmpty(partNumber)) {
                        Toast.makeText(this, "Part number is required.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    long id = db.addInventoryItem(partNumber, name, description, qty);

                    if (id == -1) {
                        Toast.makeText(this, "Could not add item.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    allItems.add(0, new InventoryItem(id, partNumber, name, description, qty));
                    applySearchAndSort();

                    etItemName.setText("");
                    etItemQty.setText("");

                    if (qty == 0) {
                        sendOutOfStockSms(name);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onDelete(int position) {
        if (position < 0 || position >= items.size()) return;

        InventoryItem item = items.get(position);
        boolean ok = db.deleteInventoryItem(item.getId());

        if (ok) {
            allItems.remove(item);
            applySearchAndSort();
        } else {
            Toast.makeText(this, "Could not delete item.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onEdit(int position) {
        if (position < 0 || position >= items.size()) return;

        InventoryItem item = items.get(position);

        EditText etPartNumber = new EditText(this);
        etPartNumber.setHint("Part number");
        etPartNumber.setText(item.getPartNumber());

        EditText etName = new EditText(this);
        etName.setHint("Item name");
        etName.setText(item.getName());

        EditText etDescription = new EditText(this);
        etDescription.setHint("Description");
        etDescription.setText(item.getDescription());

        EditText etQty = new EditText(this);
        etQty.setHint("Qty");
        etQty.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        etQty.setText(String.valueOf(item.getQty()));

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);
        layout.addView(etPartNumber);
        layout.addView(etName);
        layout.addView(etDescription);
        layout.addView(etQty);

        new AlertDialog.Builder(this)
                .setTitle("Edit item")
                .setView(layout)
                .setPositiveButton("Save", (dialog, which) -> {
                    String newPartNumber = etPartNumber.getText().toString().trim();
                    String newName = etName.getText().toString().trim();
                    String newDescription = etDescription.getText().toString().trim();
                    String newQtyStr = etQty.getText().toString().trim();

                    if (TextUtils.isEmpty(newPartNumber) || TextUtils.isEmpty(newName) || TextUtils.isEmpty(newQtyStr)) {
                        Toast.makeText(this, "Part number, name, and qty are required.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int newQty;
                    try {
                        newQty = Integer.parseInt(newQtyStr);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Qty must be a number.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (newQty < 0) {
                        Toast.makeText(this, "Quantity cannot be negative.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    boolean ok = db.updateInventoryItem(
                            item.getId(),
                            newPartNumber,
                            newName,
                            newDescription,
                            newQty
                    );

                    if (!ok) {
                        Toast.makeText(this, "Could not update item.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int oldQty = item.getQty();

                    item.setPartNumber(newPartNumber);
                    item.setName(newName);
                    item.setDescription(newDescription);
                    item.setQty(newQty);

                    applySearchAndSort();

                    if (newQty == 0 && oldQty != 0) {
                        sendOutOfStockSms(newName);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onPick(int position) {
        if (position < 0 || position >= items.size()) return;

        InventoryItem item = items.get(position);

        EditText etPickQty = new EditText(this);
        etPickQty.setHint("Quantity picked");
        etPickQty.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        EditText etRmaNumber = new EditText(this);
        etRmaNumber.setHint("RMA / Ticket number");
        etRmaNumber.setInputType(android.text.InputType.TYPE_CLASS_TEXT);

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);
        layout.addView(etPickQty);
        layout.addView(etRmaNumber);

        new AlertDialog.Builder(this)
                .setTitle("Pick Part")
                .setMessage(item.getPartNumber() + " - " + item.getName())
                .setView(layout)
                .setPositiveButton("Pick", (dialog, which) -> {
                    String qtyStr = etPickQty.getText().toString().trim();
                    String rmaNumber = etRmaNumber.getText().toString().trim();

                    if (TextUtils.isEmpty(qtyStr) || TextUtils.isEmpty(rmaNumber)) {
                        Toast.makeText(this, "Quantity and RMA/ticket number are required.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int qtyPicked;
                    try {
                        qtyPicked = Integer.parseInt(qtyStr);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (qtyPicked <= 0) {
                        Toast.makeText(this, "Pick quantity must be greater than 0.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (qtyPicked > item.getQty()) {
                        Toast.makeText(this, "Cannot pick more than current quantity.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    boolean ok = db.pickInventoryItem(item, qtyPicked, rmaNumber);

                    if (!ok) {
                        Toast.makeText(this, "Could not pick item.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int newQty = item.getQty() - qtyPicked;
                    item.setQty(newQty);
                    applySearchAndSort();

                    Toast.makeText(this, "Part picked and history saved.", Toast.LENGTH_SHORT).show();

                    if (newQty == 0) {
                        sendOutOfStockSms(item.getName());
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showSortOptionsDialog() {
        String[] sortOptions = {
                "Newest first",
                "Part number A-Z",
                "Description A-Z",
                "Quantity low to high",
                "Quantity high to low"
        };

        new AlertDialog.Builder(this)
                .setTitle("Sort Inventory")
                .setItems(sortOptions, (dialog, which) -> {
                    switch (which) {
                        case 1:
                            currentSortMode = InventoryAlgorithms.SortMode.PART_NUMBER_ASC;
                            break;
                        case 2:
                            currentSortMode = InventoryAlgorithms.SortMode.DESCRIPTION_ASC;
                            break;
                        case 3:
                            currentSortMode = InventoryAlgorithms.SortMode.QTY_LOW_TO_HIGH;
                            break;
                        case 4:
                            currentSortMode = InventoryAlgorithms.SortMode.QTY_HIGH_TO_LOW;
                            break;
                        case 0:
                        default:
                            currentSortMode = InventoryAlgorithms.SortMode.NEWEST_FIRST;
                            break;
                    }

                    applySearchAndSort();
                })
                .show();
    }

    private void showLowStockDialog() {
        EditText etThreshold = new EditText(this);
        etThreshold.setHint("Low stock threshold");
        etThreshold.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        etThreshold.setText("5");

        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        etThreshold.setPadding(pad, pad, pad, pad);

        new AlertDialog.Builder(this)
                .setTitle("Low Stock Priority Report")
                .setMessage("Items at or below the threshold will be prioritized from lowest quantity to highest quantity.")
                .setView(etThreshold)
                .setPositiveButton("Run", (dialog, which) -> {
                    String thresholdText = etThreshold.getText().toString().trim();

                    if (TextUtils.isEmpty(thresholdText)) {
                        Toast.makeText(this, "Threshold is required.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int threshold;
                    try {
                        threshold = Integer.parseInt(thresholdText);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Threshold must be a number.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (threshold < 0) {
                        Toast.makeText(this, "Threshold cannot be negative.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    ArrayList<InventoryItem> lowStockItems = InventoryAlgorithms.buildLowStockQueue(allItems, threshold);

                    if (lowStockItems.isEmpty()) {
                        new AlertDialog.Builder(this)
                                .setTitle("Low Stock Priority Report")
                                .setMessage("No inventory items are at or below the selected threshold.")
                                .setPositiveButton("OK", null)
                                .show();
                        return;
                    }

                    StringBuilder report = new StringBuilder();
                    report.append("Priority order is based on quantity on hand.\n\n");

                    int priority = 1;

                    for (InventoryItem item : lowStockItems) {
                        report.append(priority)
                                .append(". ")
                                .append(item.getPartNumber())
                                .append(" - ")
                                .append(item.getName())
                                .append("\nQty: ")
                                .append(item.getQty())
                                .append("\nDescription: ")
                                .append(item.getDescription() == null || item.getDescription().trim().isEmpty() ? "N/A" : item.getDescription())
                                .append("\n\n");

                        priority++;
                    }

                    new AlertDialog.Builder(this)
                            .setTitle("Low Stock Priority Report")
                            .setMessage(report.toString())
                            .setPositiveButton("OK", null)
                            .show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showUsageReportDialog() {
        EditText etStartDate = new EditText(this);
        etStartDate.setHint("Start date: yyyy-MM-dd");
        etStartDate.setInputType(android.text.InputType.TYPE_CLASS_DATETIME);

        EditText etEndDate = new EditText(this);
        etEndDate.setHint("End date: yyyy-MM-dd");
        etEndDate.setInputType(android.text.InputType.TYPE_CLASS_DATETIME);

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);

        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);

        layout.addView(etStartDate);
        layout.addView(etEndDate);

        new AlertDialog.Builder(this)
                .setTitle("Usage Report")
                .setMessage("Enter a date range to see how many parts were used.")
                .setView(layout)
                .setPositiveButton("Run Report", (dialog, which) -> {
                    String startDate = etStartDate.getText().toString().trim();
                    String endDate = etEndDate.getText().toString().trim();

                    if (TextUtils.isEmpty(startDate) || TextUtils.isEmpty(endDate)) {
                        Toast.makeText(this, "Start date and end date are required.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    ArrayList<String> reportLines = db.getUsageReport(startDate, endDate);

                    String report;
                    if (reportLines.isEmpty()) {
                        report = "No usage records found.";
                    } else {
                        report = TextUtils.join("\n\n--------------------\n\n", reportLines);
                    }

                    new AlertDialog.Builder(this)
                            .setTitle("Usage Report Results")
                            .setMessage(report)
                            .setPositiveButton("OK", null)
                            .show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showTopUsedPartsReport() {
        ArrayList<String> reportLines = db.getTopUsedPartsReport();

        String report;
        if (reportLines.isEmpty()) {
            report = "No usage records found.";
        } else {
            report = TextUtils.join("\n\n--------------------\n\n", reportLines);
        }

        new AlertDialog.Builder(this)
                .setTitle("Top Used Parts Report")
                .setMessage(report)
                .setPositiveButton("OK", null)
                .show();
    }

    private void sendOutOfStockSms(String itemName) {
        int status = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);

        if (status != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Out of stock. SMS permission is not allowed.", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String phone = prefs.getString(PREF_PHONE, "").trim();

        if (TextUtils.isEmpty(phone)) {
            Toast.makeText(this, "Out of stock. No SMS phone number set.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            String msg = "Inventory alert: " + itemName + " is out of stock.";
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(phone, null, msg, null, null);
            Toast.makeText(this, "SMS alert sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not send SMS on this device.", Toast.LENGTH_SHORT).show();
        }
    }
}