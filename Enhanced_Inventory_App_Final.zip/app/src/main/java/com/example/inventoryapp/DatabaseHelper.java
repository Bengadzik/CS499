package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "inventory_app.db";
    private static final int DB_VERSION = 4;

    public static final String T_USERS = "users";
    public static final String U_ID = "id";
    public static final String U_USERNAME = "username";
    public static final String U_PASSWORD = "password";

    public static final String T_INVENTORY = "inventory";
    public static final String I_ID = "id";
    public static final String I_PART_NUMBER = "part_number";
    public static final String I_NAME = "name";
    public static final String I_DESCRIPTION = "description";
    public static final String I_QTY = "qty";

    public static final String T_USAGE = "usage_history";
    public static final String UH_ID = "id";
    public static final String UH_ITEM_ID = "item_id";
    public static final String UH_PART_NUMBER = "part_number";
    public static final String UH_NAME = "name";
    public static final String UH_DESCRIPTION = "description";
    public static final String UH_QTY_USED = "qty_used";
    public static final String UH_NOTES = "notes";
    public static final String UH_CREATED_AT = "created_at";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE " + T_USERS + " (" +
                        U_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        U_USERNAME + " TEXT UNIQUE NOT NULL, " +
                        U_PASSWORD + " TEXT NOT NULL" +
                        ")"
        );

        db.execSQL(
                "CREATE TABLE " + T_INVENTORY + " (" +
                        I_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        I_PART_NUMBER + " TEXT NOT NULL, " +
                        I_NAME + " TEXT NOT NULL, " +
                        I_DESCRIPTION + " TEXT, " +
                        I_QTY + " INTEGER NOT NULL" +
                        ")"
        );

        createUsageHistoryTable(db);
    }

    private void createUsageHistoryTable(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE IF NOT EXISTS " + T_USAGE + " (" +
                        UH_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        UH_ITEM_ID + " INTEGER NOT NULL, " +
                        UH_PART_NUMBER + " TEXT NOT NULL, " +
                        UH_NAME + " TEXT NOT NULL, " +
                        UH_DESCRIPTION + " TEXT, " +
                        UH_QTY_USED + " INTEGER NOT NULL, " +
                        UH_NOTES + " TEXT, " +
                        UH_CREATED_AT + " TEXT DEFAULT CURRENT_TIMESTAMP" +
                        ")"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 4) {
            createUsageHistoryTable(db);
        }
    }

    public boolean createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(U_USERNAME, username);
        cv.put(U_PASSWORD, password);

        long result = db.insert(T_USERS, null, cv);
        return result != -1;
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(
                T_USERS,
                new String[]{U_ID},
                U_USERNAME + "=? AND " + U_PASSWORD + "=?",
                new String[]{username, password},
                null,
                null,
                null
        );

        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    public boolean usernameExists(String username) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(
                T_USERS,
                new String[]{U_ID},
                U_USERNAME + "=?",
                new String[]{username},
                null,
                null,
                null
        );

        boolean exists = c.moveToFirst();
        c.close();
        return exists;
    }

    public long addInventoryItem(String partNumber, String name, String description, int qty) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(I_PART_NUMBER, partNumber);
        cv.put(I_NAME, name);
        cv.put(I_DESCRIPTION, description);
        cv.put(I_QTY, qty);

        return db.insert(T_INVENTORY, null, cv);
    }

    public ArrayList<InventoryItem> getAllInventoryItems() {
        ArrayList<InventoryItem> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(
                T_INVENTORY,
                new String[]{I_ID, I_PART_NUMBER, I_NAME, I_DESCRIPTION, I_QTY},
                null,
                null,
                null,
                null,
                I_ID + " DESC"
        );

        while (c.moveToNext()) {
            long id = c.getLong(c.getColumnIndexOrThrow(I_ID));
            String partNumber = c.getString(c.getColumnIndexOrThrow(I_PART_NUMBER));
            String name = c.getString(c.getColumnIndexOrThrow(I_NAME));
            String description = c.getString(c.getColumnIndexOrThrow(I_DESCRIPTION));
            int qty = c.getInt(c.getColumnIndexOrThrow(I_QTY));

            list.add(new InventoryItem(id, partNumber, name, description, qty));
        }

        c.close();
        return list;
    }

    public boolean updateInventoryItem(long id, String partNumber, String name, String description, int qty) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(I_PART_NUMBER, partNumber);
        cv.put(I_NAME, name);
        cv.put(I_DESCRIPTION, description);
        cv.put(I_QTY, qty);

        int rows = db.update(
                T_INVENTORY,
                cv,
                I_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return rows > 0;
    }

    public boolean deleteInventoryItem(long id) {
        SQLiteDatabase db = getWritableDatabase();

        int rows = db.delete(
                T_INVENTORY,
                I_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return rows > 0;
    }

    public boolean pickInventoryItem(InventoryItem item, int qtyUsed, String notes) {
        if (item == null || qtyUsed <= 0 || qtyUsed > item.getQty()) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();

        try {
            int newQty = item.getQty() - qtyUsed;

            ContentValues inventoryValues = new ContentValues();
            inventoryValues.put(I_QTY, newQty);

            int rows = db.update(
                    T_INVENTORY,
                    inventoryValues,
                    I_ID + "=?",
                    new String[]{String.valueOf(item.getId())}
            );

            if (rows <= 0) {
                return false;
            }

            ContentValues usageValues = new ContentValues();
            usageValues.put(UH_ITEM_ID, item.getId());
            usageValues.put(UH_PART_NUMBER, item.getPartNumber());
            usageValues.put(UH_NAME, item.getName());
            usageValues.put(UH_DESCRIPTION, item.getDescription());
            usageValues.put(UH_QTY_USED, qtyUsed);
            usageValues.put(UH_NOTES, notes);

            long usageId = db.insert(T_USAGE, null, usageValues);

            if (usageId == -1) {
                return false;
            }

            db.setTransactionSuccessful();
            return true;

        } finally {
            db.endTransaction();
        }
    }

    public ArrayList<String> getUsageReport(String startDate, String endDate) {
        ArrayList<String> report = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(
                T_USAGE,
                new String[]{
                        UH_CREATED_AT,
                        UH_PART_NUMBER,
                        UH_NAME,
                        UH_DESCRIPTION,
                        UH_QTY_USED,
                        UH_NOTES
                },
                null,
                null,
                null,
                null,
                UH_ID + " DESC"
        );

        int recordCount = 0;
        int totalQtyPicked = 0;

        while (c.moveToNext()) {
            String createdAt = c.getString(c.getColumnIndexOrThrow(UH_CREATED_AT));
            String partNumber = c.getString(c.getColumnIndexOrThrow(UH_PART_NUMBER));
            String name = c.getString(c.getColumnIndexOrThrow(UH_NAME));
            String description = c.getString(c.getColumnIndexOrThrow(UH_DESCRIPTION));
            int qtyUsed = c.getInt(c.getColumnIndexOrThrow(UH_QTY_USED));
            String notes = c.getString(c.getColumnIndexOrThrow(UH_NOTES));

            recordCount++;
            totalQtyPicked += qtyUsed;

            String line =
                    createdAt +
                            "\nPart #: " + partNumber +
                            "\nName: " + name +
                            "\nDescription: " + description +
                            "\nQty Picked: " + qtyUsed +
                            "\nNotes: " + notes;

            report.add(line);
        }

        c.close();

        if (!report.isEmpty()) {
            String summary =
                    "Usage Report Summary" +
                            "\nTotal Usage Records: " + recordCount +
                            "\nTotal Quantity Picked: " + totalQtyPicked;

            report.add(0, summary);
        }

        return report;
    }
    public ArrayList<String> getTopUsedPartsReport() {

        ArrayList<String> report = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        String query =
                "SELECT " +
                        UH_PART_NUMBER +
                        ", SUM(" + UH_QTY_USED + ") AS total_used " +
                        "FROM " + T_USAGE +
                        " GROUP BY " + UH_PART_NUMBER +
                        " ORDER BY total_used DESC";

        Cursor c = db.rawQuery(query, null);

        while (c.moveToNext()) {

            String partNumber = c.getString(0);
            int totalUsed = c.getInt(1);

            report.add(
                    "Part #: " + partNumber +
                            "\nTotal Picked: " + totalUsed
            );
        }

        c.close();

        return report;
    }
}