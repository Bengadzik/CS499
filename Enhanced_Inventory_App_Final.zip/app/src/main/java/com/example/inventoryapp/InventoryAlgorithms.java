package com.example.inventoryapp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.PriorityQueue;

public class InventoryAlgorithms {

    public enum SortMode {
        NEWEST_FIRST,
        PART_NUMBER_ASC,
        DESCRIPTION_ASC,
        QTY_LOW_TO_HIGH,
        QTY_HIGH_TO_LOW
    }

    public static ArrayList<InventoryItem> filterItems(ArrayList<InventoryItem> source, String query) {
        ArrayList<InventoryItem> filtered = new ArrayList<>();

        if (query == null || query.trim().isEmpty()) {
            filtered.addAll(source);
            return filtered;
        }

        String searchValue = query.trim().toLowerCase();

        for (InventoryItem item : source) {
            if (containsIgnoreCase(item.getPartNumber(), searchValue)
                    || containsIgnoreCase(item.getName(), searchValue)
                    || containsIgnoreCase(item.getDescription(), searchValue)) {
                filtered.add(item);
            }
        }

        return filtered;
    }

    public static void sortItems(ArrayList<InventoryItem> items, SortMode sortMode) {
        if (sortMode == null) {
            sortMode = SortMode.NEWEST_FIRST;
        }

        switch (sortMode) {
            case PART_NUMBER_ASC:
                Collections.sort(items, Comparator.comparing(
                        item -> safeText(item.getPartNumber()),
                        String.CASE_INSENSITIVE_ORDER));
                break;

            case DESCRIPTION_ASC:
                Collections.sort(items, Comparator.comparing(
                        item -> safeText(item.getDescription()),
                        String.CASE_INSENSITIVE_ORDER));
                break;

            case QTY_LOW_TO_HIGH:
                Collections.sort(items, Comparator.comparingInt(InventoryItem::getQty));
                break;

            case QTY_HIGH_TO_LOW:
                Collections.sort(items, (first, second) -> Integer.compare(second.getQty(), first.getQty()));
                break;

            case NEWEST_FIRST:
            default:
                Collections.sort(items, (first, second) -> Long.compare(second.getId(), first.getId()));
                break;
        }
    }

    public static ArrayList<InventoryItem> buildLowStockQueue(ArrayList<InventoryItem> source, int threshold) {
        PriorityQueue<InventoryItem> lowStockQueue = new PriorityQueue<>(
                Comparator.comparingInt(InventoryItem::getQty)
                        .thenComparing(item -> safeText(item.getPartNumber()), String.CASE_INSENSITIVE_ORDER));

        for (InventoryItem item : source) {
            if (item.getQty() <= threshold) {
                lowStockQueue.offer(item);
            }
        }

        ArrayList<InventoryItem> prioritizedItems = new ArrayList<>();

        while (!lowStockQueue.isEmpty()) {
            prioritizedItems.add(lowStockQueue.poll());
        }

        return prioritizedItems;
    }

    private static boolean containsIgnoreCase(String value, String searchValue) {
        return value != null && value.toLowerCase().contains(searchValue);
    }

    private static String safeText(String value) {
        if (value == null) {
            return "";
        }
        return value.trim();
    }
}