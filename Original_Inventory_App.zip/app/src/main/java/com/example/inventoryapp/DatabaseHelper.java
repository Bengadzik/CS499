package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Keeping names simple so it's easy to follow.
    private static final String DB_NAME = "inventory_app.db";
    private static final int DB_VERSION = 1;

    // Users table
    public static final String T_USERS = "users";
    public static final String U_ID = "id";
    public static final String U_USERNAME = "username";
    public static final String U_PASSWORD = "password";

    // Inventory table
    public static final String T_INVENTORY = "inventory";
    public static final String I_ID = "id";
    public static final String I_NAME = "name";
    public static final String I_QTY = "qty";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Users table (for login)
        db.execSQL(
                "CREATE TABLE " + T_USERS + " (" +
                        U_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        U_USERNAME + " TEXT UNIQUE NOT NULL, " +
                        U_PASSWORD + " TEXT NOT NULL" +
                        ")"
        );

        // Inventory "shell" table (user fills it over time)
        db.execSQL(
                "CREATE TABLE " + T_INVENTORY + " (" +
                        I_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        I_NAME + " TEXT NOT NULL, " +
                        I_QTY + " INTEGER NOT NULL" +
                        ")"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // For this class project, keeping upgrade simple.
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + T_INVENTORY);
        onCreate(db);
    }

    // -------------------------
    // Login / Account functions
    // -------------------------

    public boolean createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(U_USERNAME, username);
        cv.put(U_PASSWORD, password);

        long result = db.insert(T_USERS, null, cv);
        return result != -1;
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(
                T_USERS,
                new String[]{U_ID},
                U_USERNAME + "=? AND " + U_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null
        );

        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    public boolean usernameExists(String username) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(
                T_USERS,
                new String[]{U_ID},
                U_USERNAME + "=?",
                new String[]{username},
                null, null, null
        );

        boolean exists = c.moveToFirst();
        c.close();
        return exists;
    }

    // -------------------------
    // Inventory CRUD functions
    // -------------------------

    public long addInventoryItem(String name, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(I_NAME, name);
        cv.put(I_QTY, qty);
        return db.insert(T_INVENTORY, null, cv);
    }

    public ArrayList<InventoryItem> getAllInventoryItems() {
        ArrayList<InventoryItem> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(
                T_INVENTORY,
                new String[]{I_ID, I_NAME, I_QTY},
                null, null, null, null,
                I_ID + " DESC"
        );

        while (c.moveToNext()) {
            long id = c.getLong(c.getColumnIndexOrThrow(I_ID));
            String name = c.getString(c.getColumnIndexOrThrow(I_NAME));
            int qty = c.getInt(c.getColumnIndexOrThrow(I_QTY));
            list.add(new InventoryItem(id, name, qty));
        }

        c.close();
        return list;
    }

    public boolean updateInventoryItem(long id, String name, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(I_NAME, name);
        cv.put(I_QTY, qty);

        int rows = db.update(
                T_INVENTORY,
                cv,
                I_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return rows > 0;
    }

    public boolean deleteInventoryItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(
                T_INVENTORY,
                I_ID + "=?",
                new String[]{String.valueOf(id)}
        );
        return rows > 0;
    }
}