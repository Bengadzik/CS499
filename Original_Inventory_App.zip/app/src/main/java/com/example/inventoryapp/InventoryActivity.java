package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.OnItemActionsListener {

    private static final String PREFS = "app_prefs";
    private static final String PREF_PHONE = "sms_phone";

    private DatabaseHelper db;
    private ArrayList<InventoryItem> items;
    private InventoryAdapter adapter;

    private EditText etItemName, etItemQty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        db = new DatabaseHelper(this);

        etItemName = findViewById(R.id.etItemName);
        etItemQty = findViewById(R.id.etItemQty);

        RecyclerView rv = findViewById(R.id.rvInventory);

        // Grid display (rubric wants a grid). 2 columns is a simple setup.
        rv.setLayoutManager(new GridLayoutManager(this, 2));

        items = db.getAllInventoryItems();
        adapter = new InventoryAdapter(items, this);
        rv.setAdapter(adapter);

        Button btnAdd = findViewById(R.id.btnAddItem);
        btnAdd.setOnClickListener(v -> addItemFromInputs());

        Button btnSms = findViewById(R.id.btnSmsSettings);
        btnSms.setOnClickListener(v -> startActivity(new Intent(this, SmsSettingsActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // In case the user updated SMS settings, or data changed, reload list.
        reloadItems();
    }

    private void reloadItems() {
        items.clear();
        items.addAll(db.getAllInventoryItems());
        adapter.notifyDataSetChanged();
    }

    private void addItemFromInputs() {
        String name = etItemName.getText().toString().trim();
        String qtyStr = etItemQty.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(qtyStr)) {
            Toast.makeText(this, "Enter item name and quantity.", Toast.LENGTH_SHORT).show();
            return;
        }

        int qty;
        try {
            qty = Integer.parseInt(qtyStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
            return;
        }

        long id = db.addInventoryItem(name, qty);
        if (id == -1) {
            Toast.makeText(this, "Could not add item.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Update UI immediately
        items.add(0, new InventoryItem(id, name, qty));
        adapter.notifyItemInserted(0);

        etItemName.setText("");
        etItemQty.setText("");

        // SMS alert trigger for inventory: out of stock (qty == 0)
        if (qty == 0) {
            sendOutOfStockSms(name);
        }
    }

    @Override
    public void onDelete(int position) {
        if (position < 0 || position >= items.size()) return;

        InventoryItem item = items.get(position);
        boolean ok = db.deleteInventoryItem(item.getId());

        if (ok) {
            items.remove(position);
            adapter.notifyItemRemoved(position);
        } else {
            Toast.makeText(this, "Could not delete item.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onEdit(int position) {
        if (position < 0 || position >= items.size()) return;

        InventoryItem item = items.get(position);

        // Simple edit dialog (Update requirement)
        EditText etName = new EditText(this);
        etName.setHint("Item name");
        etName.setText(item.getName());

        EditText etQty = new EditText(this);
        etQty.setHint("Qty");
        etQty.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        etQty.setText(String.valueOf(item.getQty()));

        // Stack the two inputs
        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);
        layout.addView(etName);
        layout.addView(etQty);

        new AlertDialog.Builder(this)
                .setTitle("Edit item")
                .setView(layout)
                .setPositiveButton("Save", (dialog, which) -> {
                    String newName = etName.getText().toString().trim();
                    String newQtyStr = etQty.getText().toString().trim();

                    if (TextUtils.isEmpty(newName) || TextUtils.isEmpty(newQtyStr)) {
                        Toast.makeText(this, "Name and qty are required.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int newQty;
                    try {
                        newQty = Integer.parseInt(newQtyStr);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Qty must be a number.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    boolean ok = db.updateInventoryItem(item.getId(), newName, newQty);
                    if (!ok) {
                        Toast.makeText(this, "Could not update item.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int oldQty = item.getQty();
                    item.setName(newName);
                    item.setQty(newQty);
                    adapter.notifyItemChanged(position);

                    // Only send if it becomes 0 (or is 0)
                    if (newQty == 0 && oldQty != 0) {
                        sendOutOfStockSms(newName);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void sendOutOfStockSms(String itemName) {
        // If permission is denied, app should still work - so we just skip SMS.
        int status = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        if (status != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Out of stock (SMS off - permission not allowed).", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String phone = prefs.getString(PREF_PHONE, "").trim();

        if (TextUtils.isEmpty(phone)) {
            Toast.makeText(this, "Out of stock (SMS off - no phone number set).", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            String msg = "Inventory alert: " + itemName + " is out of stock (qty is 0).";
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(phone, null, msg, null, null);
            Toast.makeText(this, "SMS alert sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            // If emulator/device blocks SMS, don't crash.
            Toast.makeText(this, "Could not send SMS on this device.", Toast.LENGTH_SHORT).show();
        }
    }
}