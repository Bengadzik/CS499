package com.example.inventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.VH> {

    public interface OnItemActionsListener {
        void onDelete(int position);
        void onEdit(int position);
    }

    private final ArrayList<InventoryItem> items;
    private final OnItemActionsListener listener;

    public InventoryAdapter(ArrayList<InventoryItem> items, OnItemActionsListener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_inventory_item, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        InventoryItem item = items.get(position);

        holder.tvName.setText(item.getName());
        holder.tvQty.setText(String.valueOf(item.getQty()));

        holder.btnDelete.setOnClickListener(v -> listener.onDelete(holder.getAdapterPosition()));
        holder.btnEdit.setOnClickListener(v -> listener.onEdit(holder.getAdapterPosition()));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {

        TextView tvName, tvQty;
        Button btnDelete, btnEdit;

        VH(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvRowItemName);
            tvQty = itemView.findViewById(R.id.tvRowQty);
            btnDelete = itemView.findViewById(R.id.btnDeleteRow);
            btnEdit = itemView.findViewById(R.id.btnEditRow);
        }
    }
}