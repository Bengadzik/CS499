package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private TextView tvLoginMsg;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        tvLoginMsg = findViewById(R.id.tvLoginMsg);

        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreate = findViewById(R.id.btnCreateAccount);

        btnLogin.setOnClickListener(v -> handleLogin(false));
        btnCreate.setOnClickListener(v -> handleLogin(true));
    }

    private void handleLogin(boolean isCreateAccount) {
        String user = etUsername.getText().toString().trim();
        String pass = etPassword.getText().toString().trim();

        if (TextUtils.isEmpty(user) || TextUtils.isEmpty(pass)) {
            tvLoginMsg.setText("Please enter a username and password.");
            return;
        }

        if (isCreateAccount) {
            if (db.usernameExists(user)) {
                tvLoginMsg.setText("That username already exists. Try logging in.");
                return;
            }

            boolean created = db.createUser(user, pass);
            if (!created) {
                tvLoginMsg.setText("Could not create account. Try a different username.");
                return;
            }

            tvLoginMsg.setText("Account created. You can log in now.");
        } else {
            boolean ok = db.validateUser(user, pass);
            if (!ok) {
                tvLoginMsg.setText("Login failed. Check your username/password.");
                return;
            }

            tvLoginMsg.setText("Login success.");
            Intent i = new Intent(MainActivity.this, InventoryActivity.class);
            startActivity(i);
        }
    }
}