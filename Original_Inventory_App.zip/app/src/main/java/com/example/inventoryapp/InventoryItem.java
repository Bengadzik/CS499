package com.example.inventoryapp;

public class InventoryItem {

    private final long id;
    private String name;
    private int qty;

    public InventoryItem(long id, String name, int qty) {
        this.id = id;
        this.name = name;
        this.qty = qty;
    }

    // For UI-only cases (if needed)
    public InventoryItem(String name, int qty) {
        this.id = -1;
        this.name = name;
        this.qty = qty;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQty() {
        return qty;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }
}