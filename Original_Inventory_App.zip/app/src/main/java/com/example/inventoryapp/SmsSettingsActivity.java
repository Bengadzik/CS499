package com.example.inventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsSettingsActivity extends AppCompatActivity {

    private static final int REQ_SMS = 1001;

    private static final String PREFS = "app_prefs";
    private static final String PREF_PHONE = "sms_phone";

    private TextView tvPermissionStatus;
    private EditText etPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_settings);

        tvPermissionStatus = findViewById(R.id.tvPermissionStatus);
        etPhone = findViewById(R.id.etPhoneNumber);

        Button btnRequest = findViewById(R.id.btnRequestPermission);
        Button btnSave = findViewById(R.id.btnSavePhone);
        Button btnBack = findViewById(R.id.btnBackToInventory);

        loadSavedPhone();
        updatePermissionStatus();

        btnRequest.setOnClickListener(v -> requestSmsPermission());
        btnSave.setOnClickListener(v -> savePhoneNumber());
        btnBack.setOnClickListener(v -> finish());
    }

    private void loadSavedPhone() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String phone = prefs.getString(PREF_PHONE, "");
        etPhone.setText(phone);
    }

    private void savePhoneNumber() {
        String phone = etPhone.getText().toString().trim();
        if (TextUtils.isEmpty(phone)) {
            Toast.makeText(this, "Enter a phone number first.", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.edit().putString(PREF_PHONE, phone).apply();
        Toast.makeText(this, "Phone number saved.", Toast.LENGTH_SHORT).show();
    }

    private void updatePermissionStatus() {
        int status = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        if (status == PackageManager.PERMISSION_GRANTED) {
            tvPermissionStatus.setText("Permission status: Allowed");
        } else {
            tvPermissionStatus.setText("Permission status: Not allowed");
        }
    }

    private void requestSmsPermission() {
        int status = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        if (status != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    REQ_SMS
            );
        } else {
            updatePermissionStatus();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_SMS) {
            updatePermissionStatus();
        }
    }
}